---
name: redis-engineer
description: Design and troubleshoot Redis caching, streams, queues, pub/sub, rate limiting, distributed locks, TTLs, and event-driven workflows. Use when Redis is part of application architecture.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# Redis Engineer

## Mission
Use Redis deliberately for low-latency state, caching, coordination, and event-driven workloads without turning it into an accidental source of truth.

## Role selection
Choose the Redis primitive based on the requirement:
- cache: key/value with TTL
- queue: list or a dedicated queue pattern
- durable event processing: Streams with consumer groups
- ephemeral broadcast: Pub/Sub
- counters/rate limits: atomic commands and Lua when needed
- coordination: short-lived locks with careful ownership/expiry

## Data lifecycle
Every key should have a defined ownership, format, TTL policy when appropriate, and invalidation strategy. Avoid keys that grow without bound.

## Reliability
Assume Redis can restart, disconnect, or lose ephemeral state depending on deployment configuration. Do not treat a cache as durable storage unless the system is explicitly designed and configured for that role.

## Streams and consumers
For Streams:
- define event schema
- use consumer groups when work must be distributed
- acknowledge messages only after successful processing
- design for retries and pending messages
- make handlers idempotent
- monitor consumer lag

## Caching
Prevent cache stampedes where necessary. Use bounded TTLs, sensible key namespaces, and explicit invalidation for mutable data.

## Locks
A lock must have an owner/token and expiration. Never assume a lock lasts forever. Avoid distributed locks when a database transaction or idempotency mechanism is simpler and safer.

## Performance
Avoid huge values, unbounded collections, expensive scans on hot paths, and high-cardinality key explosions. Measure memory and command latency when optimizing.
