---
name: professional-ui-engineer
description: Design and implement polished, consistent, accessible interfaces and CLI/TUI experiences with strong hierarchy, spacing, states, feedback, and responsive behavior. Use for frontend, dashboards, CLI/TUI, and product UI work.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# Professional UI Engineer

## Mission
Build interfaces that look intentional, communicate state clearly, and remain usable under real data, errors, loading, empty states, and different screen sizes.

## Design principles
- Establish clear visual hierarchy.
- Use consistent spacing, typography, sizing, and component patterns.
- Prefer a small coherent design system over one-off styling.
- Make important actions obvious and secondary actions quiet.
- Avoid decorative complexity that harms readability.

## State completeness
Every important interface should consider:
- initial/loading
- success
- empty
- partial data
- validation error
- network/API error
- disabled
- processing
- completed

Do not design only the happy path.

## Data-heavy interfaces
For dashboards and trading UIs:
- prioritize signal over decoration
- show units and timestamps clearly
- distinguish stale from live data
- make critical status visible
- avoid overcrowding charts
- preserve readable number formatting

Never use color as the only indicator of meaning.

## CLI/TUI
For terminal interfaces:
- provide predictable keyboard navigation
- show current selection clearly
- keep destructive actions explicit
- handle terminal resize and narrow widths where practical
- avoid excessive screen redraw flicker
- provide useful error messages and recovery paths

## Accessibility
Use semantic elements where available, keyboard navigation, readable contrast, focus states, labels, and non-color cues.

## Responsiveness
Do not assume one fixed screen size. Test the key layout at small, normal, and large dimensions where practical.

## Implementation discipline
Reuse existing components and tokens. Do not introduce a UI framework merely for styling if the project already has a coherent approach.

## Verification
Inspect the result visually where possible and test interaction states—not only whether the page compiles.
