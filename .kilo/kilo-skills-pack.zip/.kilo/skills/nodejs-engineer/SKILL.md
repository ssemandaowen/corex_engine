---
name: nodejs-engineer
description: Build and maintain production Node.js applications using clean modules, async-safe code, robust error handling, streams, workers, APIs, and sensible dependency choices. Use for Node.js backend, CLI, services, and runtime work.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# Node.js Engineer

## Mission
Build reliable Node.js systems with clear module boundaries, predictable asynchronous behavior, and production-grade error handling.

## Core rules
- Prefer the project's existing module system and runtime version.
- Do not convert CommonJS to ESM or vice versa unless required.
- Prefer Node.js built-ins when they are sufficient.
- Keep asynchronous control flow explicit.
- Never swallow rejected promises or callback errors.
- Avoid unbounded concurrency, memory growth, and accidental event-loop blocking.
- Validate external input at boundaries.
- Keep environment configuration separate from business logic.
- Never hard-code credentials or secrets.

## Async and concurrency
- Use async/await consistently with the surrounding code.
- Use Promise.all only when parallel work is safe and bounded.
- Use concurrency limits for large collections, API calls, and filesystem operations.
- Prefer streams for data that can exceed memory limits.
- Watch for synchronous filesystem, crypto, compression, or CPU-heavy operations on hot paths.
- Use worker threads or separate processes only when justified by CPU-bound workload or isolation needs.

## Error handling
Every external boundary should have deliberate handling for:
- invalid input
- timeouts
- unavailable dependencies
- malformed responses
- rate limits
- cancellation
- partial failure

Preserve useful error context. Do not expose secrets in errors or logs.

## APIs and services
Separate routing/transport from application logic and persistence. Keep response formatting out of domain logic. Validate request payloads before invoking deeper services.

## CLI applications
For CLIs/TUIs, keep command parsing, state management, rendering, and execution separate. Avoid printing raw internal errors directly to users when a useful user-facing message can be produced.

## Dependency policy
Before adding a package, check whether the repository already has a solution. Prefer mature, focused dependencies and avoid adding large packages for trivial functionality.

## Verification
After changes, run the project's relevant lint, typecheck, tests, and build commands when available. For runtime bugs, reproduce the failing path before declaring success.
