---
name: api-integration-engineer
description: Integrate REST, WebSocket, and third-party APIs with authentication, validation, rate-limit handling, retries, timeouts, reconnects, pagination, normalization, and observability. Use for external service integrations.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# API Integration Engineer

## Mission
Build integrations that remain correct when external APIs are slow, incomplete, rate-limited, changed, disconnected, or temporarily unavailable.

## Boundary rules
Treat every external response as untrusted input. Validate status codes, content types, required fields, timestamps, identifiers, and numeric ranges before passing data deeper into the system.

## HTTP
Every request should have:
- explicit timeout
- appropriate authentication
- bounded retry policy when safe
- response validation
- useful request correlation information

Retry only transient failures and only when the operation is safe to repeat or has an idempotency mechanism.

## Rate limits
Respect documented limits. Centralize rate-limit handling rather than letting each caller invent its own delays. Track remaining quota when the provider exposes it.

## WebSockets
Handle:
- connection establishment
- authentication
- heartbeat/keepalive
- malformed messages
- reconnect with backoff
- duplicate events
- sequence gaps when the provider supports sequencing
- graceful shutdown

Reconnect logic must not create connection storms.

## Pagination
Treat pagination as part of the API contract. Verify termination conditions and protect against infinite loops caused by repeated cursors.

## Normalization
Convert provider-specific formats into a stable internal representation at the integration boundary. Keep provider quirks out of business logic.

## Secrets
Never commit API keys. Never log authorization headers, tokens, private keys, or full sensitive payloads.

## Verification
Use mocked fixtures or sandbox endpoints where available. Test timeout, malformed response, rate-limit, reconnect, and duplicate-event behavior—not only the happy path.
