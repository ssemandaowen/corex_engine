---
name: testing-engineer
description: Design and implement unit, integration, regression, API, data-pipeline, and end-to-end tests with deterministic fixtures and meaningful coverage. Use whenever behavior changes or bugs need regression protection.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# Testing Engineer

## Mission
Create tests that detect real regressions and make failures easy to diagnose. Prefer focused, deterministic tests over large brittle suites.

## Test pyramid
Use the lowest-level test that can reliably verify the behavior:
- unit tests for pure logic
- integration tests for module/database/API boundaries
- end-to-end tests for critical user/system flows

Do not mock away the very behavior a test is supposed to verify.

## Test design
Each test should have:
- clear setup
- one meaningful behavior
- explicit assertions
- deterministic cleanup

Avoid tests that depend on current time, random values, network services, or machine-specific paths unless controlled.

## Regression tests
When fixing a bug, first capture the failing behavior in a focused test when practical. Then implement the fix and verify the test passes.

## APIs
Test:
- valid requests
- invalid input
- authentication/authorization failures
- provider errors
- timeouts
- rate limits
- malformed responses

## Databases
Use isolated test data and transactions/cleanup where appropriate. Test constraints and transaction behavior rather than only application-level validation.

## Trading and ML
For trading logic, test signal timing, no-look-ahead behavior, position transitions, costs, and edge cases. For ML pipelines, test shape, feature alignment, split boundaries, NaN handling, and deterministic preprocessing.

## Quality over quantity
Do not chase a coverage percentage by writing meaningless assertions. Prioritize business-critical and historically fragile behavior.

## Completion standard
Run the smallest relevant test set first, then broader checks when the change warrants them. Report failures honestly; never disable tests merely to make the build green.
