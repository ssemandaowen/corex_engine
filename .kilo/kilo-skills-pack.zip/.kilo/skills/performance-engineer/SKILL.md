---
name: performance-engineer
description: Diagnose and improve CPU, memory, I/O, database, network, event-loop, and latency bottlenecks using measurement and profiling. Use when a system is slow, resource-heavy, unstable under load, or approaching limits.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# Performance Engineer

## Mission
Optimize measurable bottlenecks without sacrificing correctness or creating unmaintainable complexity.

## Method
1. Define the performance problem and target metric.
2. Establish a baseline.
3. Profile or instrument the system.
4. Identify the dominant bottleneck.
5. Make one meaningful change.
6. Measure again.
7. Check correctness and regression risk.

## CPU
Look for:
- unnecessary repeated computation
- synchronous blocking work
- excessive serialization/parsing
- inefficient algorithms
- accidental O(n²) loops
- excessive logging

Do not optimize microseconds before fixing dominant costs.

## Memory
Look for:
- unbounded arrays/maps
- duplicate buffers
- retaining large objects unnecessarily
- loading entire datasets when streaming is possible
- caches without eviction

For large datasets, prefer chunking, streaming, pagination, or incremental processing.

## I/O and network
Batch operations when safe, reuse connections where supported, bound concurrency, and avoid repeated requests for identical data. Respect provider limits.

## Database
Measure slow queries and connection-pool behavior. Inspect query plans before adding indexes or rewriting queries.

## Node.js
Protect the event loop. Watch synchronous CPU-heavy work, excessive promise concurrency, large JSON operations, and large in-memory transformations.

## Trading/ML systems
For market-data and ML pipelines, measure throughput per symbol/timeframe, memory per batch, model inference latency, and end-to-end decision latency. Do not optimize by dropping data silently.

## Verification
Report before/after measurements whenever possible. If a benchmark is synthetic, label it as such and avoid treating it as production performance evidence.
