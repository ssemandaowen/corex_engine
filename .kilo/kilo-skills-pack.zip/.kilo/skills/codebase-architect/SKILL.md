---
name: codebase-architect
description: Understand unfamiliar repositories before changes; map architecture, dependencies, entry points, data flow, and boundaries. Use when exploring, planning, refactoring, or making non-trivial changes to an existing codebase.
metadata:
  author: ssemanda-owen
  version: 1.0.0
---

# Codebase Architect

## Mission
Understand the existing system before changing it. Produce the smallest architecture-aware change that solves the task without creating accidental duplication or breaking established boundaries.

## Operating procedure
1. Inspect the repository tree and identify the application entry points.
2. Locate package manifests, configuration, environment templates, database schemas, migrations, tests, build scripts, and deployment files.
3. Trace the relevant request/data flow from input to output.
4. Identify module ownership and dependency direction.
5. Find existing utilities, services, types, middleware, and abstractions that should be reused.
6. Check tests and scripts before modifying behavior.
7. State assumptions when the repository does not provide enough evidence.
8. Make the smallest coherent change.
9. Re-read affected files and run the narrowest useful verification.

## Architecture rules
- Prefer existing project conventions over generic best practices.
- Do not introduce a framework or dependency merely because it is familiar.
- Do not duplicate utilities that already exist.
- Keep business logic separate from transport, persistence, and presentation concerns.
- Keep dependency direction intentional and easy to explain.
- Avoid circular dependencies.
- Preserve public interfaces unless the task explicitly requires a breaking change.
- Do not perform broad rewrites when a focused change is sufficient.

## Investigation checklist
Before a significant edit, determine:
- entry point
- relevant modules
- configuration path
- data source
- persistence path
- external integrations
- error handling path
- logging path
- test coverage
- build/runtime assumptions

## Change discipline
When proposing multiple approaches, prefer the one with the lowest unnecessary complexity and lowest migration risk. If an architectural change is required, explain the trade-off and affected boundaries before implementing it.

## Completion standard
A task is not complete merely because code was edited. Confirm the affected path is syntactically valid, the relevant tests/checks pass where available, and no obvious duplicate or dead implementation was introduced.
