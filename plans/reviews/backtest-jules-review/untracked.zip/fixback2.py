import sys

path = 'C:/Users/SBUM/Desktop/corex/engine/backtestManager.js'
with open(path, 'r', encoding='utf-8') as f:
    s = f.read()

start = s.find('    _processDataFrame(df, options = {})')
if start == -1:
    print('no')
    sys.exit(1)
end = s.find('        // Apply range', start)
if end == -1:
    print('no2')
    sys.exit(1)

rep = '''    _processDataFrame(df, options = {}) {
        const warnings = [];
        let rawRows = [];
        try {
            rawRows = df.toArray ? df.toArray() : [];
        } catch (e) {
            rawRows = [];
        }
        let droppedBadTime = 0, droppedBadClose = 0;
        for (let i = 0; i < rawRows.length; i++) {
            const row = rawRows[i];
            const rawTime = row.time || row.Time || row.timestamp || row.datetime || row.Date || row.at;
            let timeMs = NaN;
            if (rawTime) {
                const num = Number(rawTime);
                timeMs = !isNaN(num) ? (num < 1e11 ? num * 1000 : num) : Date.parse(rawTime);
            }
            const closev = parseFloat(row.close || row.Close);
            if (!Number.isFinite(timeMs)) droppedBadTime++;
            if (!Number.isFinite(closev) || closev <= 0) droppedBadClose++;
        }
        if (droppedBadTime > 0 || droppedBadClose > 0) {
            warnings.push(\"Dropped rows: unparseable_time=\" + droppedBadTime + \", close_le_0_or_invalid=\" + droppedBadClose);
            if (Array.isArray(this._lastDataWarnings)) {
                this._lastDataWarnings = this._lastDataWarnings.concat(warnings);
            } else {
                this._lastDataWarnings = warnings.slice();
            }
        }

        let processed = df
            .select(row => {
                const rawTime = row.time || row.Time || row.timestamp || row.datetime || row.Date || row.at;
                let timeMs = NaN;
                if (rawTime) {
                    const num = Number(rawTime);
                    timeMs = !isNaN(num) ? (num < 1e11 ? num * 1000 : num) : Date.parse(rawTime);
                }
                return {
                    time: timeMs,
                    open: parseFloat(row.open || row.Open || 0),
                    high: parseFloat(row.high || row.High || 0),
                    low: parseFloat(row.low || row.Low || 0),
                    close: parseFloat(row.close || row.Close || 0),
                    volume: parseFloat(row.volume || row.Volume || 0)
                };
            })
            .where(b => Number.isFinite(b.time) && b.close > 0);

'''
s2 = s[:start] + rep + s[end:]
with open(path, 'w', encoding='utf-8') as f:
    f.write(s2)
print('ok')
